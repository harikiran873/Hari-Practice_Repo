//19. Polymorphism (Runtime + Upcasting)
//Create a class Camera with a method capture().
//Create a subclass DSLCamera that overrides the method.
//Use parent reference to call child object method (dynamic polymorphism).


package Assessments;

class Camera{
	
	void capture()
	{
	System.out.println("Capture the Image");
	}
}
class DSLCamera extends Camera{
	
	void capture()
	{
		System.out.println("Captured the images from DSLR");
	}
}

public class A_19 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Camera obj = new DSLCamera();
		obj.capture();	

	}

}
