//16.  Method Overriding with super
//Create a base class Hospital with a method emergencyService().
//Create a subclass CityHospital that overrides the method and calls parent method using super.emergencyService().
//Demonstrate overriding in main.

package Assessments;

class Hospitas
{
	void emergencyService()
	{
System.out.println("emergencyService");

}			
}

class CityHospitas extends Hospitas
{
void emergencyService()
{
	super.emergencyService();
	System.out.println("CityHospital Specific services");
	
}
}
public class Assignment10 {

	public static void main(String[] args) {
		CityHospitas obj = new CityHospitas();
        obj.emergencyService();
	}
}

