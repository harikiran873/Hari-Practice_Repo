//21.  Static Concepts
//Create a class University with:
//static variable country = "India"
//instance variable universityName
//Print values using different objects to show static effect.

package Assessments;


class university
{
	static String country= "India";
	String universityName;
	
	university(String N)
	{
	universityName = N;
	
	}
	void display()
	{
		System.out.println(country+" "+universityName);
	}
	
}
public class Assignment9 {

	public static void main(String[] args) {
		university obj3 = new university("JNTUK");
		obj3.display();
		university obj4 = new university("DRDE");
		obj4.display();
		university obj5 = new university("Manipal");
		obj5.display();
		university obj8 = new university("LPU");
		obj8.display();
		university obj7 = new university("KLU");
		obj7.display();
		
	}
	
	
}
