package Assessments;

public class Assignment01 {

	public static void main(String[] args) {
	
		ElectricCar a = new ElectricCar();
				a.fueltype();
		vehicle b = new vehicle();
				b.fueltype();
	}
	
}	
		class vehicle
		{
			void fueltype() 
			{
			System.out.println("Runs on Fuel");
			}
		}

		class ElectricCar extends vehicle
	
		{
			void fueltype()
			{
				System.out.println("Runs on Electricity");
				
			}
		}
 
	


///2 (Create a base class Vehicle with a method fuelType() which prints "Runs on fuel".
///Create a child class ElectricCar and override the fuelType() method to print "Runs on electricity".,
///Create objects of both classes and call their respective methods.