//1.Encapsulation + Getter/Setter
//WAP in Java
//Create a class named Employee with private instance variables empId, empName, and salary.
//Provide public getters and setters for all variables.
//Create a method displayDetails() to print employee details.
//Create an object in the main method and assign values using setters then display them.

package Assessments;

class Employees{
	private int empID;
	private String empName;
	private int salary;
	
		void setEmpId(int id) {
	        empID = id;
	    }

	    void setEmpName(String name) {
	        empName = name;
	    }

	    void setSalary(int sal) {
	        salary = sal;
	    }
	    int getEmpId() {
	        return empID;
	    }
	    String getEmpName() {
	        return empName;
	    }

	    int getSalary() {
	        return salary;
	    }

	    void displayDetails() {
	        System.out.println("Employee ID: " + empID);
	        System.out.println("Employee Name: " + empName);
	        System.out.println("Salary: " + salary);
	    }
	}
public class A_01 {

	public static void main(String[] args) {

        Employees e = new Employees();
        
		e.setEmpId(101);
        e.setEmpName("Kiran");
        e.setSalary(30000);
        e.displayDetails();
	}

}



