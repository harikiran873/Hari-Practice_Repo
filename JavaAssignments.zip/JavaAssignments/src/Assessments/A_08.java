//8.  Polymorphism (Dynamic Binding)
//Create a parent class Shape with a method area().
//Create subclasses Rectangle and Circle and override the area() method.
//Create a reference of Shape and assign objects of both subclasses one by one, calling area() each time.

package Assessments;

class Shapes{
	void area()
	{
		System.out.println("Area of Shape");
	}
}

class Rectangle extends Shapes {
	void area()
	{
		System.out.println("Area of Rectangle");
	}
}
class Circle extends Shapes {
	void area()
	{
		System.out.println("Area of Circle");
	}
}
public class A_08 {

	public static void main(String[] args) {
	
		Shapes S;
		
		S= new Rectangle();
		S.area();
		S= new Circle();
		S.area();

	}

}
