package Assessments;

//14. Hierarchical Inheritance
//Create a class Course with a method courseInfo().
//Create subclasses Science, Commerce, and Arts each with their own method.
//Create objects of each and call methods to show hierarchy.

class Course{
	
	void courseInfo()
	{
	System.out.println("CourseInfo:");
	}
}

class Science extends Course{
	void ScienceInfo() {
	System.out.println("Science course is avaialble");
	}
	
}
class Commerce extends Course{
	void CommerceInfo() {
	System.out.println("Commerce course is avaialble");
	}
}
class Arts extends Course{
	void ArtsInfo() {
	System.out.println("Arts course is avaialble");
	}
}
public class A_14 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Science obj1 = new Science ();
		obj1.courseInfo();
		obj1.ScienceInfo();
		
		Commerce obj2 = new Commerce();
		obj2.CommerceInfo();
		
		Arts obj3 = new Arts();
		obj3.ArtsInfo();
		
		
	}

}

