//16 create name, address,strength as their instance variables 
//Create two constructor one with two variables and one with all the three variables 
//Create a method that will display all the three parameters 
//create two object of this class and call the respective methods 

package Assessments;

class org
{
	String name;
	String address;
	int strength;
	
	org(String n, String a)
	{
		name=n;
		address=a;	
		strength=0;
	}
	org(String n, String a, int s)
	{
		name=n;
		address=a;
		strength=s;
	}
	void display()
	{
	System.out.println("Name:" + name);
	System.out.println("Address:" + address);
	System.out.println("Strength:" + strength);
	}
}
public class Assignment11 {

	public static void main(String[] args) {
		
	org obj=new org("Kiran", "#54SRnagar");
	obj.display();
	
	
	org obj1 = new org("hari", "#45686", 1200);
	obj1.display();
		

	}

}

