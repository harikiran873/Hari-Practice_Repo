// Aggregation (Has-A Relationship)
//Create a class Engine with a method engineInfo().
//Create a class Car that has-a Engine object and uses it to show engine details.
//Show aggregation in main method.


package Assessments;

class Engine
{
	void engineInfo()
	{
	System.out.println("Engine Type: Petrol, 4 Cylinder");	
	}
}

class Car
{
	Engine engine;
	Car(Engine engine) {
        this.engine = engine;
    }

    void showCarDetails() {
        engine.engineInfo();
    }
}
public class A_20 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 
		Engine eng = new Engine();
	    Car car = new Car(eng);
	    car.showCarDetails();
	}

}
