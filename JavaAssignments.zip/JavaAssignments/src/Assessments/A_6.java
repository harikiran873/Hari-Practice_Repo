
//6.  Interface Implementation
//Create an interface Payment with a method makePayment().
//Create two classes UPI and CreditCard implementing this interface and define their own payment messages.
//Call the method through interface reference.


package Assessments;

interface Payment{
	void makePayment();
	}

class UPI implements Payment {
	public void makePayment() {
	System.out.println("Payment Made through UPI");
	}
	
}

class CreditCard implements Payment {
	public void makePayment() {
		System.out.println("Payment Made through CredtCard");
}
}
public class A_6 {

	public static void main(String[] args) {
	
		Payment P;
		
		P= new UPI();
		P.makePayment();
		
		 P = new CreditCard();
	     P.makePayment();
					

		}
	}


