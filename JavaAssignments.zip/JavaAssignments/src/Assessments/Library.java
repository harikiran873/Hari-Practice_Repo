package Assessments;

public class Library {

	public static void main(String[] args) {
		
		class Library1
		{
			String LibraryName;
			Library1()
			{
			System.out.println("Welcome to the Library");
			}
			void showLocation()
			{
			System.out.println("This Library is located in Mumbai");
		}

			
		}
		
		Library1 a=new Library1();
		a.showLocation();
	
		// 11.Create a class Library with an instance variable libraryName.
				//Create a default constructor to print "Welcome to the Library!".
				//Create a method showLocation() which prints "This library is located in Mumbai".
				//Create an object in main() and call both.
	}

}
