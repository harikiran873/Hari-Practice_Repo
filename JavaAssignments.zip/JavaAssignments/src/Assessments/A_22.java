//22. Final Keyword + Constant
//Create a class GovernmentRules with a final variable MAX_WORKING_HOURS = 8
//Try modifying it inside main and observe compile-time restriction.

package Assessments;

class GovernmentRules
{
	final int MAX_WORKING_HOURS = 8;
}


public class A_22 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		GovernmentRules g1=new GovernmentRules();
		g1.MAX_WORKING_HOURS=10;

	}

}
