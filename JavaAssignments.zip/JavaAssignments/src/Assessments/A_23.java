//Constructor Chaining
//Create a class Mall with:
//Default constructor printing "Welcome to the Mall"
//Parameterized constructor calling default constructor using this()
//Demonstrate constructor chaining in main.

package Assessments;

class Mall{
	
	Mall(){
	System.out.println("Welcome to the Mall");
	}
	Mall(String Name){
		this();
		System.out.println("Mall Name:" +Name);
	}
}


public class A_23 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Mall obj = new Mall("GVK mall");
	}

}
