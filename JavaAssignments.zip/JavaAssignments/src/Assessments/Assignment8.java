//10.  Static Keyword

//Create a class Student having static variable collegeName and instance variables name and rollNo.
//Write a method to print both static and instance data.
//Create multiple objects to show static value remains constant.


package Assessments;

class Student
{
	static String collegeName="JNTU";
	String Name;
	int rollno;
	
	Student(String N,int r)
	{
	Name=N;
	rollno=r;
	
}
	void display()
	{
	System.out.println(collegeName+" "+Name+" "+rollno);
	}
	
}

public class Assignment8 
{
	public static void main(String[] args) {

	Student obj2 = new Student("Hari",12354);
	obj2.display();
	Student obj4 = new Student("Kiran",12884);
	obj4.display();
	
	}
}