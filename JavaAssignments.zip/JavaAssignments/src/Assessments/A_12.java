

//12.  Encapsulation + Validation Logic
//Create a class Account with private variables accountHolderName and balance.
//Provide setters and getters, where:
//setBalance() should not accept negative values (print a warning).
//Create an object and update values through setters only.
package Assessments;
class Account
{
	private String AccountHolderName;
	private int balance;
	
	void setName(String name)
	{
		AccountHolderName = name;
}
	
	void setBalance(int bal) {
        if (bal < 0) {
            System.out.println("Balance cannot be negative");
        } else {
            balance = bal;
        }   
	}
	String getName() {
        return AccountHolderName;
    }

    int getBalance() {
        return balance;
    }
}
public class A_12 {

	public static void main(String[] args) {
		Account a = new Account();

        a.setName("Kiran");
        a.setBalance(5000);
        a.setBalance(-200);  

        System.out.println(	"Account Holder Name:" + a.getName());
        System.out.println("Balance:"+a.getBalance());
    	}
	}

