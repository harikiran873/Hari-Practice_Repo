//Create a class named school ,create name as their instance variables 
//Create a default constructor of this class which will have a print statement to display the name of school 
//Create a method inside the class which will display a message as "This School is based out of Kolkata"
//Create a object under main method and call the constructor and the method 

package Assessments;

public class A_25 {

static class school
{	
	String name;
	
	school(){
		name = "ABC School";
		System.out.println("Name of the school:" +name);
	}
	
	void display()
	{
		System.out.print("The school is based out of Kolkata");
	}
}
	public static void main(String[] args) {
	
	school obj = new school();
	obj.display();
	}
}


