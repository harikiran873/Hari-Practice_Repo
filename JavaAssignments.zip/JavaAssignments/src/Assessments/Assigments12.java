//Create a Class named Shape with length as instance variable  , create three methods as square , rectangle , circle 
//and find out their respective areas 
//Create a object in main method and call these different methods with the instance of object 
package Assessments;

class Shape
{
	int length;
	int bredth;
	
	void square()
	{
	int area=length*length;
	System.out.println("Area of square:" +area);
	}
	void rectangle()
	{
		int area=length*bredth;
		System.out.println("Area of rectangle:" +area);	
	}
	void circle()
	{
		double area=3.14*length;
		System.out.println("Area of circle:" +area);		
	}
}
public class Assigments12 {

	public static void main(String[] args) {
		
	Shape obj = new Shape();
	
	obj.length = 10;
	
	obj.square();
	obj.rectangle();
	obj.circle();

	}
}
