//15.  Method Overloading (Bank Scenario)
//Create a class LoanCalculator with two overloaded methods:
//calculateLoan(int amount)
//calculateLoan(int amount, double interestRate)
//Print loan details accordingly. Call both methods from main.

package Assessments;

class LoanCalculator
{
	void calculateLoan(int amount)
	{
	System.out.println(amount);
	}
	void calculateLoan(int amount, double intrestRate) {
	System.out.println(amount+ " "+ intrestRate);
		
	}
}


public class A_15 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		LoanCalculator obj = new LoanCalculator();

        obj.calculateLoan(1200);
        obj.calculateLoan(12000, 7.5);

	}

}
