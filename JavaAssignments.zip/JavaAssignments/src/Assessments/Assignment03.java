package Assessments;

public class Assignment03 {

	public static void main(String[] args) {
		// 13 Create three classes:
		//Device â†’ method start()
		//Mobile extends Device â†’ method calling()
		//SmartPhone extends Mobile â†’ method internet()
		//Create object of SmartPhone and call all methods.

		class Device 
		{

		void start()
		{
		System.out.println("Nokia");
		}
		}
		class Mobile extends Device 
		{
		void calling()
		{
		System.out.println("Apple");	
		}
	
		}
		class SmartPhone extends Mobile
		{
		void internet()
		{
		System.out.println("15Pro");
		}
	
		}
		SmartPhone obj = new SmartPhone();
		obj.internet();
		obj.calling();
		obj.start();
	}
}
