package Assessments;

public class Assignment05 {

	public static void main(String[] args) {

		class Calculator
		{
		int add (int a,int b)
		{
			System.out.println(a);	
			System.out.println(b);
			return 0;
		}
		void add (double a,double b)
		{
	System.out.println(a);	
	System.out.println(b);
	
		}
	
		}
	Calculator c = new Calculator();
	c.add(15, 10);
	c.add(20, 30);
			
		
	}

}


//4Create a class Calculator with overloaded methods add():
//add(int a, int b)
//add(double a, double b)
//Call both methods inside the main method and print results.
