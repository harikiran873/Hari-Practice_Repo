//17.  Abstract Class + Real Usage
//Create an abstract class Employee with:
//abstract method: calculateSalary()
//concrete method: employeeDetails()
//Subclass FullTimeEmployee and PartTimeEmployee implementing salary calculation logic differently.

package Assessments;

abstract class Employee 
{
	abstract void calculateSalary();
	void employeeDetails()
	{
		        System.out.println("Employee details displayed");
	}
	
}
class FullTimeEmployee extends Employee {

    void calculateSalary() {
        int salary = 50000;
        System.out.println("Full Time Employee Salary: " + salary);
    }
}

class PartTimeEmployee extends Employee {

    void calculateSalary() {
        int hours = 18;
        int rate = 450;
        int salary = hours * rate;
        System.out.println("Part Time Employee Salary: " + salary);
    }
}


public class A_17 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		 Employee e1 = new FullTimeEmployee();
	        e1.employeeDetails();
	        e1.calculateSalary();

	        Employee e2 = new PartTimeEmployee();
	        e2.employeeDetails();
	        e2.calculateSalary();
	}

}
