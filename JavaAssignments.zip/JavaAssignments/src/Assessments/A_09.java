package Assessments;

//9.  Final Keyword
//Create a class Bank with a final variable IFSC and final method showIFSC().
//Try creating a subclass HDFCBank and attempt overriding the final method (should show compile-time restriction).
//Create a main method to demonstrate usage.

class Bank
{
	final String IFSC = "Bank10000002191";
	
	void showIFSC()
	{
		System.out.println("IFSC Code:" +IFSC);
	}
}

//class HDFCBANK extends Bank
//{
	// void showIFSC()
	//{
		//System.out.println(HDFC IFSC Code +IFSC);
//}
public class A_09 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Bank b = new Bank();
        b.showIFSC();
	}

}
