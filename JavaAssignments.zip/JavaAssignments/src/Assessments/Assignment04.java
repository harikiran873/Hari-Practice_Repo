package Assessments;

public class Assignment04 {

	public static void main(String[] args) {
	
	class Product
	{
	
	int productID;
	String productName;
	int price;
	
	Product()
	{
	System.out.println("Product Created");
	}
	
	Product(int p, String pn, int pr)
	{
	productID = p;
	productName = pn;
	price = pr;

	}
	void displayProduct()
	{
	System.out.println(productID);
	System.out.println(productName);
	System.out.println(price);
	}

	}
	Product obj1= new Product();
	Product obj2 = new Product(120,"nike",5555);
	obj1.displayProduct();
	obj2.displayProduct();
	
	}

}

//3.Create a class Product having instance variables productId, productName, and price.
//Implement:
//A default constructor that prints "Product Created".
//A parameterized constructor that initializes the product details.
//Write a method displayProduct() to print product details.
//Create both types of objects in the main method.